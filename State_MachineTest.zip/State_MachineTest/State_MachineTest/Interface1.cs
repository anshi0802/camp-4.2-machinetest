﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_MachineTest
{
    public interface IDetails
    {
        void DisplayAllStates();
        State SearchStateByAreaCode(int areaCode);
        void AddState(State state);
    }

    public class StateManager : IDetails
    {
        private List<State> states = new List<State>();

        public void DisplayAllStates()
        {
            foreach (var state in states)
            {
                Console.WriteLine($"Name: {state.Name}, Capital: {state.Capital}, Population: {state.Population}, Chief Minister: {state.ChiefMinister}, Area Code: {state.AreaCode}");
            }
        }

        public State SearchStateByAreaCode(int areaCode)
        {
            return states.FirstOrDefault(s => s.AreaCode == areaCode);
        }

        public void AddState(State state)
        {
            states.Add(state);
        }
    }


}
