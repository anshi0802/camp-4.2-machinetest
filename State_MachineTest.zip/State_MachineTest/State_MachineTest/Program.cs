﻿using State_MachineTest;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

class Program
{
    private static string connectionString = ConfigurationManager.ConnectionStrings["MyConnectionStrings"].ConnectionString;

    static void Main(string[] args)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            bool exit = false;


            while (!exit)
            {
                Console.WriteLine("1. Add State");
                Console.WriteLine("2. Display All States");
                Console.WriteLine("3. Search State by Area Code");
                Console.WriteLine("4. Change Population");
                Console.WriteLine("5. Change Minister Name");
                Console.WriteLine("6. Display Total Number of States");
                Console.WriteLine("7. Print Most Populated State");
                Console.WriteLine("8. Exit");

                Console.WriteLine("Enter your choice:");
                string choice = Console.ReadLine();



                switch (choice)
                {
                    case "1":
                        AddState(connection);
                        break;
                    case "2":
                        DisplayAllStates(connection);
                        break;
                    case "3":
                        SearchStateByAreaCode(connection);
                        break;
                    case "4":
                        ChangePopulation(connection);
                        break;
                    case "5":
                        ChangeMinisterName(connection);
                        break;
                    case "6":
                        int totalStates = GetTotalNumberOfStates(connection);
                        Console.WriteLine($"Total Number of States: {totalStates}");
                        break;

                    case "7":
                        GetMostPopulatedState(connection);
                        break;

                    case "8":
                        exit = true;
                        break;
                }
            }
        }
    }
    // Placeholder for AddState method
    private static void AddState(SqlConnection connection)
    {
        Console.Write("Enter Name: ");
        string name = Console.ReadLine();
        Console.Write("Enter Capital: ");
        string capital = Console.ReadLine();
        Console.Write("Enter Population: ");
        int population = int.Parse(Console.ReadLine());
        Console.Write("Enter Chief Minister: ");
        string chiefMinister = Console.ReadLine();
        Console.Write("Enter Area Code: ");
        int areaCode = int.Parse(Console.ReadLine());

        string insertQuery = "INSERT INTO States (Name, Capital, Population, ChiefMinister, AreaCode) VALUES (@Name, @Capital, @Population, @ChiefMinister, @AreaCode)";

        using (SqlCommand command = new SqlCommand(insertQuery, connection))
        {
            command.Parameters.AddWithValue("@Name", name);
            command.Parameters.AddWithValue("@Capital", capital);
            command.Parameters.AddWithValue("@Population", population);
            command.Parameters.AddWithValue("@ChiefMinister", chiefMinister);
            command.Parameters.AddWithValue("@AreaCode", areaCode);

            command.ExecuteNonQuery();
            Console.WriteLine("State added successfully!");
        }
    }

    // Placeholder for DisplayAllStates method


    private static void DisplayAllStates(SqlConnection connection)
    {
        string query = "SELECT * FROM States";

        using (SqlCommand command = new SqlCommand(query, connection))
        {
            try
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (!reader.HasRows)
                    {
                        Console.WriteLine("No states found in the database.");
                    }
                    else
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Name: {reader["Name"]}, Capital: {reader["Capital"]}, Population: {reader["Population"]}, Chief Minister: {reader["ChiefMinister"]}, Area Code: {reader["AreaCode"]}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }
    }

    /*
    string query = "SELECT * FROM States";

    using (SqlCommand command = new SqlCommand(query, connection))
    using (SqlDataReader reader = command.ExecuteReader())
    {
        while (reader.Read())
        {
            Console.WriteLine($"Name: {reader["Name"]}, Capital: {reader["Capital"]}, Population: {reader["Population"]}, Chief Minister: {reader["ChiefMinister"]}, Area Code: {reader["AreaCode"]}");
        }
    }
    */




    // Placeholder for SearchStateByAreaCode method
    private static void SearchStateByAreaCode(SqlConnection connection)
    {
        Console.Write("Enter Area Code: ");
        int areaCode = int.Parse(Console.ReadLine());

        string query = "SELECT * FROM States WHERE AreaCode = @AreaCode";

        using (SqlCommand command = new SqlCommand(query, connection))
        {
            command.Parameters.AddWithValue("@AreaCode", areaCode);

            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    Console.WriteLine($"Name: {reader["Name"]}, Capital: {reader["Capital"]}, Population: {reader["Population"]}, Chief Minister: {reader["ChiefMinister"]}, Area Code: {reader["AreaCode"]}");
                }
                else
                {
                    Console.WriteLine("State not found.");
                }
            }
        }
    }
    private static void ChangePopulation(SqlConnection connection)
    {
        Console.Write("Enter State ID: ");
        int stateId = int.Parse(Console.ReadLine());

        Console.Write("Enter New Population: ");
        int newPopulation = int.Parse(Console.ReadLine());

        string updateQuery = "UPDATE States SET Population = @Population WHERE StateID = @StateID";

        using (SqlCommand command = new SqlCommand(updateQuery, connection))
        {
            command.Parameters.AddWithValue("@StateID", stateId);
            command.Parameters.AddWithValue("@Population", newPopulation);

            int rowsAffected = command.ExecuteNonQuery();
            if (rowsAffected > 0)
            {
                Console.WriteLine("Population updated successfully!");
            }
            else
            {
                Console.WriteLine("State ID not found.");
            }

        }
    }

    // Placeholder for ChangeMinisterName method
    private static void ChangeMinisterName(SqlConnection connection)
    {
        Console.Write("Enter State ID: ");
        int stateId = int.Parse(Console.ReadLine());

        Console.Write("Enter New Chief Minister Name: ");
        string newChiefMinister = Console.ReadLine();

        string updateQuery = "UPDATE States SET ChiefMinister = @ChiefMinister WHERE StateID = @StateID";

        using (SqlCommand command = new SqlCommand(updateQuery, connection))
        {
            command.Parameters.AddWithValue("@StateID", stateId);
            command.Parameters.AddWithValue("@ChiefMinister", newChiefMinister);

            int rowsAffected = command.ExecuteNonQuery();
            if (rowsAffected > 0)
            {
                Console.WriteLine("Chief Minister name updated successfully!");
            }
            else
            {
                Console.WriteLine("State ID not found.");
            }
        }
    }
    private static int GetTotalNumberOfStates(SqlConnection connection)
    {
        string query = "SELECT COUNT(*) FROM States";

        using (SqlCommand command = new SqlCommand(query, connection))
        {
            try
            {
                int totalStates = (int)command.ExecuteScalar();
                return totalStates;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
                return 0;
            }
        }

    }

    private static void GetMostPopulatedState(SqlConnection connection)
    {
        string query = "SELECT TOP 1 Name, Population FROM States ORDER BY Population DESC";

        using (SqlCommand command = new SqlCommand(query, connection))
        {
            try
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Console.WriteLine($"Most Populated State: {reader["Name"]}, Population: {reader["Population"]}");
                    }
                    else
                    {
                        Console.WriteLine("No states found in the database.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }
    }

}









