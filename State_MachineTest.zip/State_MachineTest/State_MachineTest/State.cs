﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_MachineTest
{
    public class State
    {
        public string Name { get; set; }
        public string Capital { get; set; }
        public int Population { get; set; }
        public string ChiefMinister { get; set; }
        public int AreaCode { get; set; }

        private static int stateCount = 0;
        private static List<State> states = new List<State>();

        public State(string name, string capital, int population, string chiefMinister, int areaCode)
        {
            Name = name;
            Capital = capital;
            Population = population;
            ChiefMinister = chiefMinister;
            AreaCode = areaCode;
            stateCount++;
            states.Add(this);
        }

        public void ChangePopulation(int newPopulation)
        {
            Population = newPopulation;
        }

        public void ChangeMinisterName(string newChiefMinister)
        {
            ChiefMinister = newChiefMinister;
        }

        public static int GetTotalNumberOfStates()
        {
            return stateCount;
        }

        public static State GetMostPopulatedState()
        {
            return states.OrderByDescending(s => s.Population).FirstOrDefault();
        }
    }

}
